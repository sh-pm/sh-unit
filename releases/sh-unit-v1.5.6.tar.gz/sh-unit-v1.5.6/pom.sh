GROUP_ID=bash
ARTIFACT_ID=sh-unit
VERSION=v1.5.6

declare -A DEPENDENCIES=( \
    [sh-pm]=v4.0.0@github.com/sh-pm \
    [sh-logger]=v1.4.0@github.com/sh-pm \
);
